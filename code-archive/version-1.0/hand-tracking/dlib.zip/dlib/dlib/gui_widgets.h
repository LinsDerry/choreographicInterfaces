// Copyright (C) 2005  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.

#ifdef DLIB_ALL_SOURCE_END
#include "dlib_basic_cpp_build_tutorial.txt"
#endif

#ifndef DLIB_GUI_WIDGETs_
#define DLIB_GUI_WIDGETs_



#include "gui_widgets/widgets.h"



#endif // DLIB_GUI_WIDGETs_

