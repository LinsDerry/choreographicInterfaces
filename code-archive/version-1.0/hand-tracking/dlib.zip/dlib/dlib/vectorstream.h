// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_VECTORSTReAMh_
#define DLIB_VECTORSTReAMh_

#include "vectorstream/vectorstream.h"
#include "vectorstream/unserialize.h"


#endif // DLIB_VECTORSTReAMh_

