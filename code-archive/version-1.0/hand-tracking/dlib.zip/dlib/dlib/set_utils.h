// Copyright (C) 2007  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SET_UTILs_H_
#define DLIB_SET_UTILs_H_ 

#include "set_utils/set_utils.h"

#endif // DLIB_SET_UTILs_H_ 



